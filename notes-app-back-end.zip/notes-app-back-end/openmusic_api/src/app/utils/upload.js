const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Pastikan folder upload ada
const uploadDir = path.resolve(__dirname, '../../uploads/covers');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Konfigurasi penyimpanan file
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const albumId = req.params.id || 'unknown';
    const ext = path.extname(file.originalname) || '.png';
    const filename = `cover-${albumId}-${Date.now()}${ext}`;
    cb(null, filename);
  },
});

// Filter file
const fileFilter = (req, file, cb) => {
  const allowedMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];

  if (allowedMimes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    const error = new multer.MulterError('LIMIT_UNEXPECTED_FILE');
    error.message = 'Tipe file harus berupa gambar (png, jpg, jpeg, webp)';
    cb(error);
  }
};

// Buat instance multer
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 512 * 1024, // 512KB
  },
});

// Export middleware dengan error handling manual
const uploadCover = (req, res) => {
  return new Promise((resolve, reject) => {
    const multerMiddleware = upload.single('cover');

    multerMiddleware(req, res, (err) => {
      if (err) {
        reject(err);
      } else {
        // Cek jika tidak ada file yang diupload
        if (!req.file) {
          const error = new Error('No files were uploaded');
          error.code = 'NO_FILE';
          reject(error);
          return;
        }
        resolve();
      }
    });
  });
};

module.exports = { uploadCover };
