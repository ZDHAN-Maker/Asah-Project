const { nanoid } = require('nanoid');
const pool = require('../db');
const NotFoundError = require('../utils/error/NotFoundError');

class AlbumsService {
  constructor() {
    this.pool = pool;
  }

  async addAlbum({ name, year }) {
    const id = `album-${nanoid(16)}`;
    const createdAt = new Date().toISOString();
    const updatedAt = createdAt;

    const query = {
      text: 'INSERT INTO albums(id, name, year, created_at, updated_at) VALUES($1, $2, $3, $4, $5) RETURNING id',
      values: [id, name, year, createdAt, updatedAt],
    };

    try {
      const res = await pool.query(query);
      if (!res.rows[0].id) {
        throw new Error('Failed to add album');
      }
      return res.rows[0].id; // Return the album ID as a string
    } catch (error) {
      console.error(error);
      throw new Error('An error occurred while adding the album');
    }
  }

  async getAlbumById(id) {
    const query = {
      text: 'SELECT id, name, year, cover_url FROM albums WHERE id = $1',
      values: [id],
    };

    const result = await this.pool.query(query);

    // PERBAIKAN: Cek jika album tidak ditemukan
    if (result.rows.length === 0) {
      return null; // Return null instead of throwing error
    }

    const album = result.rows[0];

    // Get songs related to the album
    const songsQuery = {
      text: 'SELECT id, title, performer FROM songs WHERE album_id = $1',
      values: [id],
    };

    const songsResult = await this.pool.query(songsQuery);

    return {
      id: album.id,
      name: album.name,
      year: album.year,
      coverUrl: album.cover_url || null,
      songs: songsResult.rows || [], // Return empty array if no songs found
    };
  }

  async editAlbumById(id, { name, year }) {
    const updatedAt = new Date().toISOString();
    const query = {
      text: 'UPDATE albums SET name=$1, year=$2, updated_at=$3 WHERE id=$4 RETURNING id',
      values: [name, year, updatedAt, id],
    };

    const res = await this.pool.query(query);

    // PERBAIKAN: Cek jika album tidak ditemukan
    if (res.rows.length === 0) {
      throw new NotFoundError('Album tidak ditemukan untuk diperbarui');
    }

    return res.rows[0].id;
  }

  async deleteAlbumById(id) {
    const query = {
      text: 'DELETE FROM albums WHERE id=$1 RETURNING id',
      values: [id],
    };
    const res = await this.pool.query(query);

    if (!res.rowCount) {
      throw new NotFoundError('Album not found for deletion');
    }

    return res.rows[0].id; // Return the album ID as a string
  }

  // Di service/AlbumService.js
  async updateAlbumCover(albumId, coverPath) {
    try {
      const query = {
        text: 'UPDATE albums SET cover_url = $1 WHERE id = $2 RETURNING id',
        values: [coverPath, albumId],
      };

      const result = await this._pool.query(query);
      return result.rows.length > 0;
    } catch (error) {
      console.error('Database update error:', error);
      throw error;
    }
  }
}

module.exports = AlbumsService;
