// src/app/utils/upload.js
const multer = require('multer');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/covers'),
  filename: (req, file, cb) => {
    const ext = (file.originalname.split('.').pop() || 'png').toLowerCase();
    cb(null, `cover-${req.params.id}-${Date.now()}.${ext}`);
  }
});

const fileFilter = (_, file, cb) => {
  if (/^image\/(png|jpe?g|webp)$/i.test(file.mimetype)) cb(null, true);
  else cb(new Error('Tipe file tidak didukung'), false);
};

const uploadCover = multer({
  storage,
  fileFilter,
  limits: { fileSize: 512000 }, // 500 KB
}).single('cover');

module.exports = { uploadCover };
